# ABOUT THE PROJECT

This is the project number 20 of WhitehatJR. 
It has some sprites and it has some logics of to check that is a sprite is touching the other or not. 
It is coded in javascript. 
To change the logic, edit the code in the file sketch.js.

# ABOUT ME
![My Image](swastik.png)

- 👋 Hi, I’m [Swastik Bhattacharjee](https://github.com/Swastik-WhitehatJR).
- 👀 I’m interested in Programming and designing.
- 🌱 I’m currently learning Web Development.
- 💞️ I’m now learning to it on WhitehatJR.
- 📫 How to reach me by mentioning me in github at @Swastik-WhitehatJR.
- 💌 How to mail me in swastikbhattacharjee.07@gmail.com (my email id).
